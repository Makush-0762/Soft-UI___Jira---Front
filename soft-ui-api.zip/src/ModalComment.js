import React, {useEffect, useState} from "react";
import Modal from 'react-bootstrap/Modal';
import "./layaut/ModalComment.css"
import Div from './elements/Div';
import P from './elements/P';
import A from './elements/A';
import Img from './elements/Img';
import lock from "./img/lock.png"
import aye from "./img/eye.png"
import like from "./img/like.png"
import share from "./img/share.png"
import skrepka from "./img/skrepka.png"
import stuctyre from "./img/structure.png"
import cepka from "./img/cepka.png"
import arrow from "./img/arrow.png"
import elips from "./img/ellipsis.png"
import flash from "./img/flash.png"
import profile from "./img/profile.png"
import Accordion from 'react-bootstrap/Accordion';
import pencil from "./img/pencil.svg"
import settings from "./img/setting.png"
import axios from "axios";
import Select from 'react-select'

export default function ModalComment (){
    const [task, setTask] = useState([]);
    const [taskModal, setTaskModal] = useState('');
    const [users, setUsers] = useState([]);
    const [status, setStatus] = useState([]);

    const [show, setShow] = useState(false);


    const options = status.map(stat => (
            { value: stat.name, label: stat.name }
    ))
    const [selectedOption, setSelectedOption] = useState(null);

    const action = [
            { value: 'action', label: 'Action' },
            { value: 'someText', label: 'Some Text' },
            { value: 'otherText', label: 'Other Text' },
        ];
    const [selectedAction, setSelectedAction] = useState(null);
    
        
        // const MyComponent = () => (
        //     <Select options={options} />
        // )

    useEffect(() => {
        axios
        .get(`http://127.0.0.1:8000/api/task`)
        .then(response => {
            setTask(response.data.response.task.data);
            // setTaskModal(response.data.response.task.data);
            console.log(response.data.response.task);
        })
        .catch(error => {
            console.error(error);
        });
    }, []);
    
    useEffect(() => {
        axios
        .get(`http://127.0.0.1:8000/api/users`)
        .then(response => {
            setUsers(response.data.response.users.data);
            console.log(response.data.response.users.data);
        })
        .catch(error => {
            console.error(error);
        });
    }, []);

    useEffect(() => {
        axios
        .get(`http://127.0.0.1:8000/api/status`)
        .then(response => {
            setStatus(response.data.response.status.data);
            console.log(response.data.response.status.data);
        })
        .catch(error => {
            console.error(error);
        });
    }, []);

    const openModal = (taskName) => {
        setTaskModal(taskName);
        setShow(true);
    };

    return(
        <Div className='body_modal'>
            <button className='bodyUpdatePencil' onClick={() => setShow(true)}>
                <Img src={pencil} className='imgUpdate' />
    </button>
            <Modal show={show} onHide={() => setShow(false)}  dialogClassName="modal-90w" aria-labelledby="example-custom-modal-styling-title" >
                <Modal.Header closeButton>
                    <Modal.Title style={{fontSize:'14px', width:'100%'}}>
                        <Div className='body_HeadTetle' style={{display:'flex', justifyContent:'space-between'}}>
                            <Div>
                                <span className="LinkBread">&#128394;&#65039; Add epic</span> / 
                                <span className="LinkBread" style={{marginLeft:'10px'}} >
                                    <input type="checkbox" className="form-check-input item-leftBlock" id="exampleCheck1"/> 
                                    <span className='numberSprint item-leftBlock'>SCT-6</span>
                                </span>
                            </Div>
                            <Div className='body_iconCloseModal'>
                                <Img src={lock} className='modalImg'/>
                                <span className='modalImg'><Img src={aye} /> 2</span>
                                <Img src={like} className='modalImg'/>
                                <Img src={share} className='modalImg'/>
                                <Img src={elips} className='modalImg'/>
                            </Div>
                        </Div>        
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Div className='bodyModalCard'>
                        <Div className='body_left_block'>
                            {/* {task.map(task => (
                                <P className="title_modal">{task.name}</P>
                             ))} */}
                            {task.map((item) => (
                                <P className="title_modal" onClick={() => openModal(item.name)}>
                                    {item.name}
                                </P>
                            ))}
                            <Div className='subtitle_Button'>
                                <Div className='itemSub'>
                                    <P className='statistic'><Img src={skrepka} className='iconSubtitle'/> Attach</P>
                                </Div>
                                <Div className='itemSub'>
                                    <P className='statistic'><Img src={stuctyre} className='iconSubtitle'/> Add a child issue</P>
                                </Div>
                                <Div className='itemSub'>
                                    <P className='epicSub'><Img src={cepka} className='iconSubtitle'/> Link issue | <Img src={arrow} className='iconEpic'/></P>
                                </Div>
                                <Div className='itemSub'>
                                    <P className='epicSub'><Img src={elips} className='iconSubtitle'/></P>
                                </Div>
                            </Div>
                            <Div className='formDescription'>
                                <label for="floatingTextarea2">Description</label>
                                <div className="form-floating" style={{padding:'10px 0px'}}>
                                    <textarea className="form-control" placeholder="Leave a comment here" id="floatingTextarea2" style={{height: '100px'}}></textarea>
                                </div>
                            </Div>
                            <Div>
                                <P><strong>Activity</strong></P>
                            </Div>
                            <Div className='body_filt'>
                                <Div className='filt'>
                                <P>Show: </P>
                                <P><strong>ALL</strong></P>
                                <P><strong>Comments</strong></P>
                                <P><strong>History</strong></P>
                                </Div>
                                <Div style={{marginRight:'10px'}}>
                                    Newest first
                                </Div>
                            </Div>
                            <Div className='addComment'>
                                <Div>
                                    <Img src={profile} className='imgSearch'/>
                                </Div>
                                <div className="form-floating" style={{width: '100%', marginLeft:'20px'}}>
                                    <textarea className="form-control"  placeholder="Leave a comment here" id="floatingTextarea"></textarea>
                                    <label for="floatingTextarea">Comments</label>
                                    <P><strong>Pro tip:</strong> press <span><strong>M</strong></span> to comment</P>
                                </div>
                            </Div>
                            {users.map(user => (
                                <Div className='addComment' style={{marginTop:'30px'}}>
                                    <Div>
                                        <Img src={profile} className='imgSearch'/>
                                    </Div>
                                    <div style={{width: '100%', marginLeft:'20px'}}>
                                        <P><strong>{user.name}</strong> 25 травня 2023 р. о 17:35</P>
                                        <P>Это ж из коробки есть</P>
                                        <P><strong>Edit . Delete . &#9787;</strong></P>
                                    </div>
                                </Div>
                            ))}
                    </Div>
                        <Div className='body_righy_Block' style={{with:'40%'}}>
                            <Div className='body_Select' >
                                <Div className='body_Select item-rightBlock'>
                                <Select
                                        placeholder='Status'
                                        className='Selecttask'
                                        defaultValue={selectedOption}
                                        onChange={setSelectedOption}
                                        options={options}
                                    />
                                </Div>
                                <Div className='body_Select item-rightBlock'>
                                <Select
                                        placeholder='Action'
                                        className='Selecttask'
                                        defaultValue={selectedAction}
                                        onChange={setSelectedAction}
                                        options={action}
                                    />
                                </Div>
                        </Div>
                            <Div className='body_acordion'>
                                <Accordion className='w-100' style={{marginTop:'20px'}}>
                                    <Accordion.Item eventKey="0" active>
                                        <Accordion.Header>Details</Accordion.Header>
                                        <Accordion.Body>
                                            <table className="table">
                                                <thead>
                                                    <tr className="colModal">
                                                        <th scope="col" style={{verticalAlign:'top'}}>Assignee</th>
                                                        <td>
                                                            <Img src={profile} className='imgSearch' style={{marginRight:'15px'}}/> Unassigned <br/>
                                                            <A href='#' className='link_proj'>Assign to me</A>
                                                        </td>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr lassName="colModal">
                                                        <th scope="row">Labels</th>
                                                        <td>None</td>
                                                    </tr>
                                                    <tr className="colModal">
                                                        <th scope="row">Sprint</th>
                                                        <td><A href='#' className='link_proj'>SCT Sprint 1</A></td>
                                                    </tr>
                                                    <tr className="colModal"> 
                                                        <th scope="row">Sory point estimate</th>
                                                        <td colspan="2">None</td>
                                                    </tr>
                                                    <tr className="colModal">
                                                        <th scope="row">Reporter</th>
                                                        <td colspan="2">
                                                            <Img src={profile} className='imgSearch' style={{marginRight:'15px'}}/> Кузьмин Олександр Сергійович
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </Accordion.Body>
                                    </Accordion.Item>
                                </Accordion>
                            </Div>
                            <Div className='body_create'>
                                <Div>
                                    <P>Created 21 May 2023 p. o 20:22</P>
                                    <P>Updated 25 May 2023 p. o 17:35</P>
                                </Div>
                                <Div style={{cursor:'pointer'}}>
                                    <Img src={settings} className='imgCreate'/> <strong>Configure</strong>
                                </Div>
                            </Div>
                        </Div>
                    </Div>
                </Modal.Body>
            </Modal>
        </Div>
    )
}