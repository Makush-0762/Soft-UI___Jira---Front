import React, {useEffect, useState} from "react";
import './layaut/Jira.css';
import LayoutInside from "./layaut/LayoutInside";
import Div from "./elements/Div"
import P from "./elements/P"
import A from "./elements/A"
import Form from "./elements/Form"
import Input from "./elements/Input"
import Label from "./elements/Label"
import Img from "./elements/Img"
import {Link} from 'react-router-dom';
import elips from "./img/ellipsis.png"
import magnifier from "./img/magnifier.png"
import profile from "./img/profile.png"
import arrow from "./img/arrow.png"
import arrowB from "./img/arrowB.png"
import analitic from "./img/analytics.png"
import axios from "axios";
import ModalComment from "./ModalComment";
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
import ModalAddPerformens from './elements/ModalAddPerformens'



export default function Jira() {
    const [modalShow, setModalShow] = React.useState(false);

    const [task, setTask] = useState([]);


    // const [status, setStaus] = useState([]);

    // const options = status.map(stat => (
    //     { value: stat.name, label: stat.name }
    //     ))
    // const [selectedOption, setSelectedOption] = useState(null);


    useEffect(() => {
        axios
        .get(`http://127.0.0.1:8000/api/task`)
        .then(response => {
            setTask(response.data.response.task.data);
            console.log(response.data.response.task.data);
        })
        .catch(error => {
            console.error(error);
        });
    }, []);

    // useEffect(() => {
    //     axios
    //     .get(`http://127.0.0.1:8000/api/status`)
    //     .then(response => {
    //         setStaus(response.data.response.status.data);
    //         // console.log(response.data.response.status.data);
    //     })
    //     .catch(error => {
    //         console.error(error);
    //     });
    // }, []);


    return (
        <>
        <LayoutInside>
            <Div className='mainProject'>
                <Div>
                    <Div>
                    <Link to="/projects" className="LinkBread">Пректи</Link> / <Link className="LinkBread" to="/projects/jira"> Jira</Link>
                    </Div>
                    <Div className='bodyTitle'>
                    <P className='titleBacklog'>Беклог</P>
                    <Div className="linkTitle"><A href='#' ><Img src={elips} /></A></Div>
                    </Div>
            
                    <Div className='body_Search-Backlog'>
                    <Div className='bodyForm'>
                        <Form className='inputBacklogr bodyForm-Item'>
                        <Label htmlFor='idSearchBacklog'>
                            <A href='#'><Img src={magnifier} className='magnifierBacklog' /></A>
                            <Input type='text' className='inputSearchBacklog' id='idSearch' placeholder='Пошук по беклогу' />
                        </Label>
                        </Form>
        
                        <Div className='bodyForm-Item'>
                        <P className='epic'>Епік <Img src={arrow} className='iconEpic' /></P>
                        </Div>
                    </Div>
                    <Div>
                        <P className='statistic'><Img src={analitic} /> Статистика</P>
                    </Div>
                    </Div>
                    <Div className='body_Tasks'>
            
                        <Div className='bodyTitleTasks'>
                            <Div className='titleTasts'><Img src={arrowB} className='iconEpic' /><strong> SCT Sprint 1</strong>&#32;&#32;   10 May - 24 May (17 issues)</Div>
                            <Div className='right-Block'>
                            <Div className='body_Zero'>
                                <P className='grey_Zero'>0</P>
                                <P className='blue_Zero'>0</P>
                                <P className='green_Zero'>0</P>
                            </Div>
                            <P className='sprintTasks'>Запустити спринт</P>
                            <Div className="linkTitleTasks"><A href='#' ><Img src={elips} /></A></Div>
                            </Div>
                        </Div>
                        {task.map(task => (
                            <Div className='task' variant="primary">
                                <Div className='left-BlockTast'>
                                    <input type="checkbox" className="form-check-input item-leftBlock" id="exampleCheck1" />
                                    <P className='numberSprint item-leftBlock'>SCT-{task.id}</P>
                                    <P className='numberSprint item-leftBlock'>{task.name}</P>
                                    <ModalComment   />
                                </Div>
                                <Div className='right-BlockTask'>
                                    <P className='quintitu item-rightBlock'>-</P>
                                    <Div className='body_Select item-rightBlock'>
                                        {/* <Select 
                                            placeholder='Status'
                                            className='Selecttask'
                                            defaultValue={selectedOption}
                                            onChange={setSelectedOption}
                                            options={options}
                                        /> */}
                                        <span className="badge text-uppercase rounded-5 text-black" style={{backgroundColor:'rgba(217, 217, 217, 0.7)',width:'125px', padding:'10px', fontSize:'15px', fontWeight:'500'}}>Secondary</span>
                                    </Div>
                                    <Div className='body_ImgProfile item-rightBlock'>
                                        <DropdownButton
                                            
                                            as="secondary"
                                            key="secondary"
                                            id={`dropdown-variants-secondary`}
                                            variant={"secondary".toLowerCase()}
                                            title="Виконавці: "
                                        >
                                            <Dropdown.Item style={{width:'200px'}}><Img src={profile} className='imgSearch' />Action</Dropdown.Item>
                                            <Dropdown.Divider />
                                            <Dropdown.Item variant="primary" onClick={() => setModalShow(true)}>
                                                <A  className='addPerformer'  href='#'>+ ВИКОНАВЕЦЬ
                                                <ModalAddPerformens 
                                                    show={modalShow}
                                                    onHide={() => setModalShow(false)}
                                                />
                                                </A>
                                                </Dropdown.Item>
                                        </DropdownButton>
                                    </Div>
                                </Div>
                            </Div>
                        ))} 
                    </Div>
                </Div>
            </Div>
        </LayoutInside>
        </>
    );
}



