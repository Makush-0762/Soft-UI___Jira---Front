import React, {useState} from "react";
import Div from "../../elements/Div";
import Nav from "../../elements/Nav";
import UL from "../../elements/UL";
import LI from "../../elements/LI";
import Img from "../../elements/Img";
import './HeaderInside.css';
import logo from "../../img/Jira-logo.png"
import magnifier from "../../img/magnifier.png"
import menu from "../../img/menu.png"
import A from "../../elements/A";
import Span from "../../elements/Span";
import Input from "../../elements/Input";
import Form from "../../elements/Form";
import Label from "../../elements/Label";
import message from "../../img/Mess.png"
import question from "../../img/question.png"
import settings from "../../img/setting.png"
import profile from "../../img/profile.png"
import arrow from "../../img/arrow.png"
import {Link, useLocation  } from 'react-router-dom';

export default function HeaderInside () {

    const location = useLocation();
    const [activItem, setActivItem] = useState(-1);

    function HundlerActiveItem(index) {
        return () => {
            if (activItem === index) {
                setActivItem(-1); // Знімаємо активний клас, якщо натиснули на активний елемент
            } else {
                setActivItem(index);
            }
        };
    }
    
    return (
        <>
            <header className="headerInside">
                <Div className='logoBlock'>
                    <Div className='menu_icon item_menuIcon'>
                        <A href='#' className='menu_icon'><Img src={menu} className='menuImg'/></A>
                    </Div>
                    <Div className='item_menuIcon'>
                        <Link to='/'><Img src={logo} className='logo logo_Inside'/></Link>
                    </Div>
                </Div>
                <Div className='bodyList'> 
                    <Nav className='navBobyList'>
                        <Div className={location.pathname === '/projects/jira' ? 'bodyLink bodyLinkactive' : 'bodyLink'}>
                            <Div className={activItem === 1 ? 'body_link_Meny active' : 'body_link_Meny'} >
                                <Link to='/projects/jira' className="link_menu">
                                    Ваша робота 
                                </Link>
                                <Img src={arrow} alt='arrow' className='arrow' onClick={HundlerActiveItem(1)}/>
                                <Div className={activItem === 1 ? 'modalMenuItem mMactive' : 'modalMenuItem'}>
                                    <Div className="top_section">
                                        <Div className='tabs_body'>
                                            <Div className='tabs_item active_tab'>Призначено мені</Div>
                                            <Div className='tabs_item'>Недавні</Div>
                                            <Div className='tabs_item'>Дошки</Div>
                                        </Div>
                                    </Div>
                                </Div>
                            </Div>
                        </Div>
                        <Div className={location.pathname === '/projects/' ? 'bodyLink bodyLinkactive' : 'bodyLink'}>
                            <Div className={activItem === 2 ? 'body_link_Meny active' : 'body_link_Meny'} >
                                <Link to='/projects/' className="link_menu">
                                    Пректи
                                </Link>
                                <Img src={arrow} alt='arrow' className='arrow' onClick={HundlerActiveItem(2)}/>
                            </Div>
                        </Div>
                        <Div className={location.pathname === '/' ? 'bodyLink bodyLinkactive' : 'bodyLink'}>
                            <Div className={activItem === 3 ? 'body_link_Meny active' : 'body_link_Meny'} >
                                <Link to='/' className="link_menu">
                                    Фільтри 
                                </Link>
                                <Img src={arrow} alt='arrow' className='arrow' onClick={HundlerActiveItem(3)}/>
                            </Div>
                        </Div>
                        <Div className={location.pathname === '/projects/jira' ? 'bodyLink bodyLinkactive' : 'bodyLink'}>
                            <Div className={activItem === 4 ? 'body_link_Meny active' : 'body_link_Meny'} >
                                <Link to='/projects/jira' className="link_menu">
                                    Дашбоарди 
                                </Link>
                                <Img src={arrow} alt='arrow' className='arrow' onClick={HundlerActiveItem(4)}/>
                            </Div>
                        </Div>
                        <Div className={location.pathname === '/projects/jira' ? 'bodyLink bodyLinkactive' : 'bodyLink'}>
                            <Div className={activItem === 5 ? 'body_link_Meny active' : 'body_link_Meny'} >
                                <Link to='/projects/jira' className="link_menu">
                                    Команди 
                                </Link>
                                <Img src={arrow} alt='arrow' className='arrow' onClick={HundlerActiveItem(5)}/>
                            </Div>
                        </Div>
                        <Div className={location.pathname === '/projects/jira' ? 'bodyLink bodyLinkactive' : 'bodyLink'}>
                            <Div className={activItem === 6 ? 'body_link_Meny active' : 'body_link_Meny'} >
                                <Link to='/projects/jira' className="link_menu">
                                    Програми 
                                </Link>
                                <Img src={arrow} alt='arrow' className='arrow' onClick={HundlerActiveItem(6)}/>
                            </Div>
                        </Div>
                    </Nav>
                </Div>
                <Div className='body_field_Search'>
                    <Div className='field_Search'>
                        <Form className='inputHeader'>
                            <Label htmlFor='idSearch'>
                                <Img src={magnifier} className='magnifier'/>
                                <Input type='text' className='inputSearch' id='idSearch'  placeholder={'Search'}/>
                            </Label>
                        </Form>
                        <Div className='iconSearch'>
                            <Div className='body_img'><Img src={message} className='icon_search'/></Div>
                            <Div className='body_img'><Img src={question} className='icon_search'/></Div>
                            <Div className='body_img'><Img src={settings} className='icon_search'/></Div>
                            <Div className='body_img'><Img src={profile} className='icon_search'/></Div>
                        </Div>
                    </Div>
                </Div>
            </header>
        </>
    );
    
}

