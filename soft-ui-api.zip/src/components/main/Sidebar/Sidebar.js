import React from "react";
import './Sidebar.css';
import Div from "../../../elements/Div"
import Img from "../../../elements/Img"
import Accordion from 'react-bootstrap/Accordion';
import UL from "../../../elements/UL";
import LI from "../../../elements/LI";
import A from "../../../elements/A";
import P from "../../../elements/P";
import projectIcon from "../../../img/10402.svg"
import cart from "../../../img/Cart.png"
import backlog from "../../../img/Backlog.png"
import board from "../../../img/Board.png"
import code from "../../../img/Code.png"
import stProject from "../../../img/strProject.png"
import addLanguage from "../../../img/AddLanguage.png"
import settings from "../../../img/setting.png"
import { Link } from "react-router-dom";

export default function Sidebar () {


        
    return (
        <>
            <Div className="sidebar">
                <Div style={{position:'reletive'}}>
                    <Div className='bodyProjectName'>
                        <Img src={projectIcon} className='ImgProgect'/>
                        <Div>
                            <P className='TitleProject'><strong>Jira</strong></P>
                            <P className='descriptionProject'>Проект по розробці ПЗ</P>
                        </Div>
                    </Div>

                    <Accordion defaultActiveKey={['0']} alwaysOpen>
                        <Accordion.Item  eventKey="0" style={{border:'none'}}>
                            <Accordion.Header className="buton" tyle={{border:'none', backgroundColor:'transparent'}}><strong>ПЛАНУВАННЯ</strong></Accordion.Header>
                            <Accordion.Body style={{padding:'0px'}}>
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item" style={{borderBottom:'none'}}><Link to="/projects" className='linkSidebar'><Img src={cart} className='ImgProgectItem'/>Проекти</Link></li>
                                    <li class="list-group-item activeX" style={{borderBottom:'none'}}><Link to="/projects" className='linkSidebar'><Img src={backlog} className='ImgProgectItem'/>Беклог</Link></li>
                                    <li class="list-group-item" style={{borderBottom:'none'}}><Link to="/projects" className='linkSidebar'><Img src={board} className='ImgProgectItem'/>Дошка</Link></li>
                                </ul>
                            </Accordion.Body>
                        </Accordion.Item>
                        <Accordion.Item  style={{border:'none', display:'flex', flexDirection:'column'}} eventKey="1">
                            <Accordion.Header><strong>РОЗРОБКА</strong></Accordion.Header>
                            <Accordion.Body style={{padding:'0px'}}>
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item" style={{borderBottom:'none'}}><A href='#' className='linkSidebar'><Img src={code} className='ImgProgectItem'/>Код</A></li>
                                </ul>
                            </Accordion.Body>
                        </Accordion.Item>
                    </Accordion>
                    <hr/>
                    <ul class="list-group list-group-flush" >
                        <li class="list-group-item" style={{borderBottom:'none'}}><A href='#' className='linkSidebar'><Img src={stProject} className='ImgProgectItem'/>Сторінка проекту</A></li>
                        <li class="list-group-item" style={{borderBottom:'none'}}><A href='#' className='linkSidebar'><Img src={addLanguage} className='ImgProgectItem'/>Додати ярлик</A></li>
                        <li class="list-group-item" style={{borderBottom:'none'}}><A href='#' className='linkSidebar'><Img src={settings} className='ImgProgectItem'/>Налагодження пректу</A></li>
                    </ul>
                    <Div className='bodyBottomTitle'>
                        <P className='bottomTitle' style={{textAlign:'center'}}>Цей прект керується командою</P>
                        <P className='bottomLink'>Подробиці</P>
                    </Div>
                </Div>
            </Div>
        </>
    )
}

