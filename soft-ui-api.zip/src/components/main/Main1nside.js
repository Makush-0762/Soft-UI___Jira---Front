import React from "react";
import './Main1nside.css';
import Sidebar from './Sidebar/Sidebar';

export default function Main1nside ({children}) {
    return (
        <>
            <main className="main">
                <Sidebar />
                {children}
            </main>
        </>
    )
}

