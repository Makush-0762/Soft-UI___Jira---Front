import React from "react";

export default function Button ({children, className}) {

    return(
        <>
            <div className={className}>
                {children}
            </div>
        </>
    ) 
} 