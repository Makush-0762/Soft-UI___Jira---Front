import './App.css';
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import HomeLogIn from './HomeLogIn';
import HomeRegicter from './HomeRegicter';
import Jira from './Jira';
import Projects from './Projects';
import ModalComment from './ModalComment';


function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={ <HomeLogIn />} />
          <Route path='/register' element={ <HomeRegicter />} />
          <Route path='/projects' element={ <Projects />} />
          <Route path='/projects/jira' element={ <Jira />} />
          <Route path='/modal' element={ <ModalComment />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
